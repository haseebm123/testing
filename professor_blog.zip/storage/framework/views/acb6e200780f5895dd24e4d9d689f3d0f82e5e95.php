<?php $__env->startSection('header-script'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-section'); ?>
    <br>
    <section class="input-validation dashboard-analytics">
        <div class="row">
            <div class="col-12">

                <!-- account start -->
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="card-title">Account</div>
                        </div>
                        <div class="card-body page-users-view">
                            <div class="row">
                                <div class="users-view-image">
                                    <img src="<?php echo e(asset('app-assets/images/portrait/small/avatar-s-11.jpg')); ?>"
                                        class="users-avatar-shadow w-100 rounded mb-2 pr-2 ml-1" alt="avatar">
                                </div>
                                <div class="col-12 col-sm-9 col-md-6 col-lg-5">
                                    <table>
                                        <?php if(isset($user->first_name)): ?>
                                            <tr>
                                                <td class="font-weight-bold">First Name</td>
                                                <td><?php echo e($user->first_name); ?></td>
                                            </tr>
                                        <?php endif; ?>
                                        <?php if(isset($user->last_name)): ?>
                                            <tr>
                                                <td class="font-weight-bold">Last Name</td>
                                                <td><?php echo e($user->last_name); ?></td>
                                            </tr>
                                        <?php endif; ?>
                                        <?php if(isset($user->email)): ?>
                                            <tr>
                                                <td class="font-weight-bold">Email</td>
                                                <td><?php echo e($user->email); ?></td>
                                            </tr>
                                        <?php endif; ?>
                                        <?php if(isset($user->phone_number)): ?>
                                            <tr>
                                                <td class="font-weight-bold">Phone Number</td>
                                                <td><?php echo e($user->phone_number); ?></td>
                                            </tr>
                                        <?php endif; ?>
                                        <?php if(isset($user->status)): ?>
                                            <tr>
                                                <td class="font-weight-bold  ">Status</td>
                                                <td>
                                                    <?php if($user->status == 1): ?>
                                                        Active
                                                    <?php else: ?>
                                                        Deactive
                                                    <?php endif; ?>

                                                </td>
                                            </tr>
                                        <?php endif; ?>

                                    </table>
                                </div>

                                <div class="col-12">
                                    <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-primary mr-1"><i
                                            class="feather icon-edit-1"></i> Edit</a>
                                    

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- account end -->
            </div>
        </div>


    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-section'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-script'); ?>
    <script>
        $(function() {
            $("#example1").DataTable({
                "responsive": true,
                "lengthChange": false,
                "autoWidth": false,
                "buttons": []
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        });
    </script>

    <script type="text/javascript">
        var APP_URL = <?php echo json_encode(url('/')); ?>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Projects\professor_blog_laravel9\professor_blog\resources\views/admin/user/show.blade.php ENDPATH**/ ?>