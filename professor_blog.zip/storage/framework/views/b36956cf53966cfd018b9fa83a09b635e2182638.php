<?php $__env->startSection('header-script'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-section'); ?>
<br>
<section id="dashboard-analytics">
    <div class="container-fluid">

        <div class="row">
        <div class="col-12">
         <div class="card">
            <div class="card-header">
                <h1>Professor Section</h1>
             

            </div>
            <!-- /.card-header -->
            <div class="card-body">
            <table class="table table-striped dataex-html5-selectors" >
              <thead>
                <tr>
                    <th>No</th>

                    <th>Name</th>
                    
                    <th>Image</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
              </thead>

                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                  <tr>
                    <td><?php echo e($key+1); ?></td>

                    <td><?php echo e($item->name??null); ?></td>
                    
                    <?php
                        $image = $item->image??null;
                    ?>
                    <td><img class="round" src='<?php echo e(asset("documents/professor_section/$image")); ?>' alt="avatar" height="40" width="40"></td>
                     <td>
                      <div class="form-group">
                        <div class="custom-control custom-switch custom-switch-off-danger custom-switch-on-success">
                            <input type="checkbox" class="custom-control-input switch-input" id="<?php echo e($item->id); ?>" <?php echo e(($item->status==1)?"checked":""); ?>>
                            <label class="custom-control-label" for="<?php echo e($item->id); ?>"></label>
                        </div>
                      </div>
                    </td>

                    <td>
                      <a   href="<?php echo e(route('professor.show',$item->id)); ?>"><span class="action-edit"><i class="feather icon-eye"></i></span></a>
                       <a   href="<?php echo e(route('professor.edit',$item->id)); ?>"><span class="action-edit"><i class="feather icon-edit"></i></span></a>
                       &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                      
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php endif; ?>
                </table>
            </div>
            <!-- /.card-body -->
         </div>
      </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-section'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-script'); ?>


<script>



  $(function () {
    $(".example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": []
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');

  });
</script>

<script type="text/javascript">

 var APP_URL = <?php echo json_encode(url('/')); ?>

 $(".switch-input").change(function(){

    if(this.checked)
        var status=1;
    else
        var status=0;
    $.ajax({
        url : "<?php echo e(route('professor-change-status')); ?>",
        type: 'GET',
        /*dataType: 'json',*/
        data: {'id': this.id,'status':status},
        success: function (response) {
          if(response)
            {
             toastr.success(response.message);
            }else{
             toastr.error(response.message);
            }
        }, error: function (error) {
            toastr.error("Some error occured!");
        }
    });
});



</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Projects\professor_blog_laravel9\professor_blog\resources\views/admin/professor_section/index.blade.php ENDPATH**/ ?>