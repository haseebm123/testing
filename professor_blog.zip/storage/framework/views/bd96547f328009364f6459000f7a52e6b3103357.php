<?php $__env->startSection('content'); ?>
    <section id="line">
        <div class="container">
            <div class="line">
                <hr>
            </div>

        </div>
    </section>


    <section class="section7 mt-5">
        <div class="container-fluid">
            <div class="row">
                 <?php
                    $image = $data->image??null
                ?>
                <div class="col-xl-6" id="writer-imagee" data-aos="flip-up"data-aos-duration="3000">
                    <img src='<?php echo e(asset("documents/professor_section/$image")); ?>' alt="" class="">
                </div>

                <div class="col-lg-6 p-5" id="writer-content" data-aos="flip-left" data-aos-duration="3000">



                    <p>Professor</p>
                    <h1><?php echo e($data->name??null); ?></h1>
                    <div class="title">


                        <br>

                        <span>
                            <?php echo $data->body??null; ?>


                        </span>

                        <br>
                        <br>
                        <?php if(isset($data)): ?>

                        <button>Read More</button>
                        <?php endif; ?>
                        <br>
                        <br>

                    </div>


                </div>


            </div>
        </div>
        <img src="<?php echo e(asset('front/assets/img/recccctangle.png')); ?>" alt="" class="img-fluid recccctangle">
    </section>

    <section class="section10">
        <div class="container mt-5">
              <?php echo $data->add_info??null; ?>

        </div>

        <img src="<?php echo e(asset('front/assets/img/rightsidetoprec.png')); ?>" alt="" class="img-fluid rightsidetoprec">
        <img src="<?php echo e(asset('front/assets/img/leftsiderectangle.png')); ?>" alt="" class="img-fluid leftsiderectangle">
        <img src="<?php echo e(asset('front/assets/img/rightsidebottomrec.png')); ?>" alt="" class="img-fluid rightsidebottomrec">
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('front.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Projects\nicole-barnes\resources\views/front/pages/professor.blade.php ENDPATH**/ ?>