<?php $__env->startSection('header-script'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-section'); ?>
    <br>
    <section class="input-validation dashboard-analytics">
        <div class="row">
            <div class="col-12">

                <!-- account start -->
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="card-title">Account</div>
                        </div>
                        <div class="card-body page-users-view">
                            <div class="row">
                                <div class="users-view-image">

                                    <?php if(isset($data->image)): ?>
                                        <img src='<?php echo e(asset("documents/human_section/$data->image")); ?>'
                                        class="users-avatar-shadow w-100 rounded mb-2 pr-2 ml-1" alt="Home Image">
                                    <?php endif; ?>
                                </div>
                                <div class="col-12 col-sm-9 col-md-6 col-lg-5">
                                    <table>

                                            <tr>
                                                <td class="font-weight-bold">Title</td>
                                                <td><?php echo e($data->title??null); ?></td>
                                            </tr>


                                            <tr>
                                                <td class="font-weight-bold">Name</td>
                                                <td><?php echo e($data->name??null); ?></td>
                                            </tr>


                                            <tr>
                                                <td class="font-weight-bold">Body</td>
                                                <td><?php echo $data->add_info; ?></td>
                                            </tr>

                                    </table>
                                </div>

                                <div class="col-12">
                                    <a href="<?php echo e(route('human.edit', $data->id)); ?>" class="btn btn-primary mr-1"><i
                                            class="feather icon-edit-1"></i> Edit</a>
                                    <form method="post" action="<?php echo e(route('human.destroy', $data->id)); ?>"
                                        style="margin-top: -38px;margin-left: 150px";>
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-outline-danger"
                                            onclick="return confirm('Are You Sure Want To Delete This..??')"
                                            class="btn btn-default generalsetting_admin"><i class="feather icon-trash-2"></i>Delete</button>
                                    </form>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- account end -->
            </div>
        </div>


    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-section'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-script'); ?>


    <script type="text/javascript">
        var APP_URL = <?php echo json_encode(url('/')); ?>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Projects\professor_blog_laravel9\professor_blog\resources\views/admin/human_section/show.blade.php ENDPATH**/ ?>