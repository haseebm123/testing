<?php $__env->startSection('header-script'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-section'); ?>
    <br>
    <section class="input-validation dashboard-analytics">
        <div class="row">
            <div class="col-12">

                <!-- account start -->
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <div class="card-title">Account</div>
                        </div>
                        <div class="card-body page-users-view">
                            <div class="row">
                                <div class="users-view-image ">
                                    <?php if(isset($data->image)): ?>
                                        <img src='<?php echo e(asset("documents/professor_section/$data->image")); ?>'
                                        class="users-avatar-shadow w-100 rounded mb-2 pr-2 ml-1" alt="Home Image">

                                    <?php endif; ?>
                                </div>
                                <div class="col-12 col-sm-9 col-md-6 col-lg-5">
                                    <table>

                                            <tr>
                                                <td class="font-weight-bold">Name </td>
                                                <td><?php echo e($data->name??null); ?></td>
                                            </tr>


                                            <tr>
                                                <td class="font-weight-bold">Body </td>
                                                <td><?php echo $data->body??null; ?></td>
                                            </tr>
                                            <tr>
                                                <td class="font-weight-bold">Additional Information </td>
                                                <td><?php echo e($data->add_info??null); ?></td>
                                            </tr>

                                    </table>
                                </div>

                                <div class="col-12">
                                    <a href="<?php echo e(route('professor.edit', $data->id)); ?>" class="btn btn-primary mr-1"><i
                                            class="feather icon-edit-1"></i> Edit</a>
                                    

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- account end -->
            </div>
        </div>


    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-section'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-script'); ?>
    <script>
        $(function() {
            $("#example1").DataTable({
                "responsive": true,
                "lengthChange": false,
                "autoWidth": false,
                "buttons": []
            }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
            $('#example2').DataTable({
                "paging": true,
                "lengthChange": false,
                "searching": false,
                "ordering": true,
                "info": true,
                "autoWidth": false,
                "responsive": true,
            });
        });
    </script>

    <script type="text/javascript">
        var APP_URL = <?php echo json_encode(url('/')); ?>

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Projects\professor_blog_laravel9\professor_blog\resources\views/admin/professor_section/show.blade.php ENDPATH**/ ?>