<?php $__env->startSection('header-script'); ?>
<style type="text/css">

</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body-section'); ?>

<section id="dashboard-analytics">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12">
                            <div class="card bg-analytics text-white">
                                <div class="card-content">
                                    <div class="card-body text-center">
                                        <img src="<?php echo e(asset('app-assets/images/elements/decore-left.png')); ?>" class="img-left" >
                                        <img src="<?php echo e(asset('app-assets/images/elements/decore-right.png')); ?>" class="img-right" >
                                        <div class="avatar avatar-xl bg-primary shadow mt-0">
                                            <div class="avatar-content">
                                                <i class="feather icon-award white font-large-1"></i>
                                            </div>
                                        </div>
                                        <div class="text-center">
                                            <h1 class="mb-2 text-white">WELLCOME TO ADMIN DASHBOARD ,</h1>
                                            <p class="m-auto w-75"><?php echo e(auth()->user()->first_name??null); ?>-<?php echo e(auth()->user()->last_name??null); ?></p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                    


                </section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('footer-section'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer-script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/layout/layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Projects\professor_blog_laravel9\professor_blog\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>